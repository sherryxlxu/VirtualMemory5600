/* test_pm_heap.c  */

/*
 * test_pm_heap.c / Practicum I
 *
 * Zhixuan Cao,Xiaoliang Xu / CS5600 / Northeastern University
 * Spring 2023 / Mar 21, 2023
 *
 */

/*
 * This program is a to test if the custom heap could be safely accessed from different threads.
 */

#include "pm_heap.h"
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
void* pm_malloc_results[PAGE_NUM];


 //Main program
int main() {
  pthread_t threads[VIRTUAL_NUM], threadsFree[VIRTUAL_NUM],threadExtra,queue_thread,access_thread;

  pthread_mutex_init(&pm_mutex,NULL);
  
  //initial virtual array
  pthread_create(&queue_thread, NULL, initialize_virtual,NULL);
  pthread_join(queue_thread,NULL);
  

  /*
   * Test Case 1: The physical memory is 10MB. Allocate 20MB in to the memory.
   * There should be 10 swap files in the array.
   * The physical memory should be fully allocated with various size.
   * First ten pages in the virtual memory should be stored in swap file and the element int the array should be -4.
   * The time_page tracks the order of virtual pages, which should start from 10 to 19.
   */
  for (int i = 0; i < VIRTUAL_NUM; i++) {
    // thread_args[i] = 1;
    pthread_create(&threads[i], NULL, pm_malloc_wrapper, i+1);
  }
  for (int i = 0; i < VIRTUAL_NUM; i++) {
    pthread_join(threads[i], &pm_malloc_results[i]); /* Store the pointers in the pm_malloc_result array */
  }

  /*
   * Test Case 2: Allocate additional page as heap is full. 
   * The virtual memory should be full.
   */
  usleep(10000);
  pthread_create(&threadExtra,NULL,pm_malloc_wrapper,1);
  pthread_join(threadExtra, NULL);
  usleep(10000);

  /*
   * Test Case 3: Free random pages in heap. 
   * There should be 2 spaces freed in virtual_page[] from index 0 to 19. The space that freed shows -1.
   * If the pointer is stored in physical memory, than space in physical_memory would be freed.
   */
  // usleep(10000);
  for (int i = 1; i < 3; i++){
    pthread_create(&threadsFree[i], NULL, pm_free_wrapper,pm_malloc_results[i]);
  }
  for (int i = 1; i < 3; i++){
    pthread_join(threadsFree[i], NULL);
  }
  /* 
   * Test Case 4: Access the specific page in the virtual memory. 
   * If the accessed page is in disk or physical memory, it should be rearranged to the last element of physical_page.
   * For example :virtual_page[9]:-4 -This page is in the swap file.
   * It is put back into the physical array.
   * 
   */
  usleep(10000);
  pthread_create(&access_thread, NULL, access_page, 9);
  pthread_join(access_thread, NULL);
  // for (int i = 0; i < 3; i++) {
  //   // thread_args[i] = 1;
  //   printf("i: %d\n", i+9);
  //   pthread_create(&access_thread[i], NULL, access_page, i+9);
  // }
  // for (int i = 0; i < 3; i++) {
  //   // printf("i: %d\n", i);
  //   pthread_join(access_thread[i], NULL); /* Store the pointers in the pm_malloc_result array */
  // }

  pthread_mutex_destroy(&pm_mutex);
  return 0;


}