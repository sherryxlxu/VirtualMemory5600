# Practicum I

This program implements a virtual memory system with Least Recent Use (LRU) Algorithm.
virtual_page[]: Index- virtual page number. Element- time of current page entering the physical memory.
time_page[]: Index- time of page entering the physical memory. Element- virtual page number.
physical_page[]:Index- physical page number. Element-size that allocates in the physical memory.
## Usage

To build the code, run `make`. 
The program test out LRU Algorithm in virtual memory system.

Test Case 1: The physical memory is 10MB. Allocate 20MB in to the memory.. 

Test Case 2: Allocate additional page as heap is full.
Test Case 3: Free random pages in heap. 

Test Case 4: Access the specific page in the virtual memory.

## Contributors

Xiaoliang Xu
Zhixuan Cao

