/* pm_heap.c  */

/*
 * pm_heap.c / Practicum I
 *
 * Zhixuan Cao,Xiaoliang Xu / CS5600 / Northeastern University
 * Spring 2023 / Mar 21, 2023
 *
 */

/*
 * This program implements a virtual memory system with Least Recent Use (LRU) Algorithm.
 * virtual_page[]: Index- virtual page number. Element- time of current page entering the physical memory.
 * time_page[]: Index- time of page entering the physical memory. Element- virtual page number.
 * physical_page[]:Index- physical page number. Element-size that allocates in the physical memory.
 */

#include "pm_heap.h"
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>


/*
 * initialize_virtual(): Initialize the value of virtual_page and phys_page, thus all the spaces are freed.
 */

void *initialize_virtual(){
  pthread_mutex_lock(&pm_mutex);
  int length;
  length = sizeof(virtual_page)/sizeof(virtual_page[0]);
  for(int i = 0; i < length; i++){
    virtual_page[i] = -1;
  }
  for(int i = 0; i < PAGE_NUM; i++){
    phys_page[i] = -1;
    time_page[i] = -1;
  }
  pthread_mutex_unlock(&pm_mutex);
}

/*
 * pm_malloc(size_t size): 
 * Allocate size into phys_page. If phys_page is full, free the least recent use page and store the value to the swap file. 
 */

void *pm_malloc(size_t size){
  if(size <= 0 || size > PM_PAGE_SIZE) {  /* check if size is suitable for heap  */
    printf("Size is bigger than a single page size.\n");
    return NULL;
  }
  // global variable counter to track the timing of allocation.
  // As counter > 9. phys_page is full. The system needs to swap the page file.
  if (counter > 9){
    // The element of index 0 of time_page is the Least Recent Use Page.
    int index_swap = time_page[0];
    // The element of index 0 of phys_page is the allocated size of current page.
    int value = phys_page[0];
    // The slot is the page that need to be swapped.
    void *swap_slot = phys_mem + PM_PAGE_SIZE * 0;
    printf("Page that need to be swapped in virtual_page[]: %d.\n Value in the physical memory: %d.\n",index_swap, value);
    //to do
    pm_swap_helper(swap_slot,index_swap,value);
    
  }
  //find an available space in virtual page
  //size of virtual memory is twice as physical memory
  int i = 0;
  void *slot = NULL;
  while (i < VIRTUAL_NUM) {
    //Can not allocate if physical memory is full.
    if(counter > 9){
      break;
    }
    //If virtual_page[i] = -1, then current page is available.
    if (virtual_page[i] == -1){
      //update virtual page
      virtual_page[i] = counter;
      //update time page according to virtual page
      time_page[counter] = i;
      //update physical page according to time_page
      phys_page[counter] = size;
      counter ++;
      slot = phys_mem + PM_PAGE_SIZE * i;
      break;     
    }   
    i++;
  }
  //virtual memory is full
  if (i == VIRTUAL_NUM){
    printf("Virtual memory is full.\n");
    return NULL;
  }

  printf("counter: %d\n", counter);
  // int length = sizeof(virtual_page)/sizeof(virtual_page[0]);
  for (int m=0; m < FULL_VIRTUAL_ARRAY ; m++){
    printf("virtual_malloc %d: %d\n", m, virtual_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("time_malloc %d: %d\n", m, time_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("phys_malloc %d: %d\n", m, phys_page[m]);
  }
  return slot;
}

/*
 * update_time_physical_page(int index, int array[]): 
 * As a page is freed, time_page[] and phys_page[] need to be rearranged. 
 */
void* update_time_physical_page(int index, int array[]){
  for (int j= index; j < PAGE_NUM - 1; j ++){
      int temp_a =array[j];
      array[j] =array[j+1];
      array[j+1]=temp_a;
    }
}

/*
 * update_virtual_page(): 
 * As time_page[] is rearranged, virtual_page[] need to be updated according to the index and element of time_page. 
 */

void* update_virtual_page(){
  for (int i = 0; i < PAGE_NUM; i++){
    if (time_page[i] == -1){
      continue;
    }
    int index = time_page[i];
    virtual_page[index] = i;
  }
}

/*
 * update_physical_page(): 
 * As time_page[] is rearranged, phys_page[] need to be updated. 
 */
void* update_physical_page(){
  for(int i = 0; i < PAGE_NUM; i++){

      if (time_page[i] == -1){

        phys_page[i] = -1;
      }
    }
}

//update the counter
void* update_new_counter(){
  int new_count = 0;
  for(int i = 0; i < PAGE_NUM; i++){
    if (phys_page[i] >= 0){
      new_count +=1;
    }
    counter=new_count;
  }
}
 /*
  * pm_free()-free a block of memory to the pm-heap
  * 
  * ptr: the pointer to the memory to free
  *
  */
void* pm_free(void *ptr){

  //free space only if physical memory is not empty.
  if (counter >= 0){
    int page_index = (ptr - (void*)phys_mem) / (1024 * 1024);  
    
    //Page is stored in the disk.
    if(virtual_page[page_index] == -4){
      printf("Page %d is stored in the disk.\n", page_index);
      for(int i = 0; i < PAGE_NUM; i++){
        if (virtual_page[i + VIRTUAL_NUM] == page_index){
          //Delete that file.
          removeFile(virtual_page[i + VIRTUAL_NUM]);
          virtual_page[i + VIRTUAL_NUM] =-1;
          virtual_page[page_index] = -1;
          
        }
      }
    }
    if(virtual_page[page_index] >= 0){
      printf("Page %d is in the physical memory.\n", page_index);
      int temp = virtual_page[page_index];
      virtual_page[page_index] = -1;
      time_page[temp] = -1;
      update_time_physical_page(temp,time_page);
      update_virtual_page();
    }
    update_physical_page(0,phys_page);
    update_new_counter();
  }   
  printf("counter: %d\n", counter);
  for (int m=0; m < FULL_VIRTUAL_ARRAY ; m++){
    printf("virtuafree %d: %d\n", m, virtual_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("time_free %d: %d\n", m, time_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("phys_free %d: %d\n", m, phys_page[m]);
  }

}

/*
 * pm_swap_helper(void *ptr, int index_swap, int value):
 * 10 pages at the end of virtual_page[] is to store the index of page that stored in swap file.
 * The name of each swap file is the index of virtual page. 
 * The content of each swap file is the value that stored in that virtual page.
 */
void* pm_swap_helper(void *ptr, int index_swap, int value){
  //Can only swap file if the physical memory is not empty.
  if (counter >= 0){
    for (int j = 0; j < PAGE_NUM; j++) {
        if (virtual_page[j + VIRTUAL_NUM] < 0){
          //The extra space in virtual page is to store the index of swapped page.
          virtual_page[j + VIRTUAL_NUM] = index_swap;
          //Name the swap file as index_swap, and store the value as the content of swap file.
          storeArray(index_swap,value);
          break;
        }
    }
    //Current page is swapped. Assign -4 to current page.
    virtual_page[index_swap] = -4;
    //Current page is swapped. Assign -1 to free the space in time_page.
    time_page[0] = -1;
    //reassign time_page
    update_time_physical_page(0,time_page);
    //reassign virtual_page
    update_virtual_page();
    //free physical page, since it is swapped.
    phys_page[0]=-1;
    //update phys_page
    update_time_physical_page(0,phys_page);
    //update counter.
    update_new_counter();
  }

}

 /*
  * pm_malloc_wrapper()-helper function for pthread_create
  * 
  * arg: size that would be used in pm_malloc()
  *
  */
void *pm_malloc_wrapper(void *arg) {    
    pthread_mutex_lock(&pm_mutex);
    // Cast the argument to a size_t
    size_t size = (size_t) arg;
    // Call the pm_malloc() function
    void *ptr = pm_malloc(size);
    pthread_mutex_unlock(&pm_mutex);
    // Return the result of the pm_malloc() function
    return ptr;
}

 /*
  * pm_free_wrapper()-helper function for pthread_create
  * 
  * arg: pointer that would be used in pm_free()
  *
  */

void *pm_free_wrapper(void *arg) {    
    pthread_mutex_lock(&pm_mutex);
    pm_free(arg);
    pthread_mutex_unlock(&pm_mutex);
}

/*
 * storeArray(int index, int value):
 * Name the swap file as index_swap, and store the value as the content of swap file.
 */
void *storeArray(int index, int value){
    FILE *fp;
    char fileName[20];
    sprintf(fileName, "%d.txt", index);

    fp = fopen(fileName, "w");
    if (fp == NULL)
    {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    fprintf(fp, "%d", value);
    fclose(fp);
}

/*
 * removeFile(int index):
 * Remove the file, if the file name matches the index.
 */
int removeFile(int index){
    char fileName[20];
    sprintf(fileName, "%d.txt", index);

    int result = remove(fileName);
    if (result == 0)
        return 1;
    else
        return 0;
}

/*
 * fetchContent(int index)
 * Get the content of file, if the file name matches the index.
 */
int fetchContent(int index){
    FILE *fp;
    char fileName[20];
    sprintf(fileName, "%d.txt", index);

    fp = fopen(fileName, "r");
    if (fp == NULL)
    {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    int value;
    fscanf(fp, "%d", &value);
    fclose(fp);
    return value;
}

/*
 * access_page(int num):
 * Access the page naming as the num in virtual memory.
 * If virtual_page[num] == -1, it means the space is freed.
 * If virtual_page[num] == -4, it means the page is in swap file. Access the page, and move the page into physical memory. Track the order.
 * If virtual_page[num] >= 0, it means the page is in physical. Access the page, and reassign the order of page.
 */
void* access_page(int num) {
  pthread_mutex_lock(&pm_mutex);
  // printf("counter_access:%d\n",counter);
  int result;
  printf("virtual_page[%d]:%d\n", num,virtual_page[num]);
  //If virtual_page[num] == -1, it means the space is freed.
  if (virtual_page[num] == -1){
    result = -1;
    printf("Page is freed: %d\n", result);
  } else if (virtual_page[num] == -4){
    for (int i =0; i< PAGE_NUM; i++){
      //Find file name in swap space.
      if (virtual_page[i + VIRTUAL_NUM] == num){
        
        //malloc the result in virtual memory and physical memory, rearrange the order.
        if (counter <= 9){
          //get the content of file.
          result = fetchContent(num);
          printf("Page %d in the disk is reaccessed: %d\n", num, result);
          removeFile(num);
          virtual_page[i+VIRTUAL_NUM] = -1;
          update_new_counter();
          virtual_page[num] = counter;
          // for(int m= 0; m < VIRTUAL_NUM; m++){
          //   if (virtual_page[m] == -1){
          //     virtual_page[m]
          //   }
          // }
          time_page[counter] = num;
          phys_page[counter] = result;
          update_virtual_page();
      
        } else {
          printf("There is no physical memory to access.\n");
        }
       
        
      }
    }
    update_new_counter();
  } else {
    //Find the page in physical memory.
    int index = virtual_page[num];
    
    virtual_page[num] = -1;
    result = phys_page[index];
    printf("value_get_from_physical: %d\n", result);
    //Since the page is accessed, rearrange the order.
    for(int i =index; i<PAGE_NUM - 1; i++){
      if(phys_page[i+1] == -1){
        break;
      }
      phys_page[i] = phys_page[i+1];
      phys_page[i+1] = result;
    }
    for(int i =index; i<PAGE_NUM - 1; i++){
      if(time_page[i+1] == -1){
        break;
      }
      time_page[i] = time_page[i+1];
      time_page[i+1] = result;
    }
    // phys_page[index] = -1;
    // time_page[index] = -1;
    // update_time_physical_page(index,phys_page);
    // update_time_physical_page(index,time_page);
    // for(int k = 0; k <PAGE_NUM; k++){
    //   if (phys_page[k] == -1){
    //     phys_page[k] = result;
    //     time_page[k] = result;
    //   }
    // }
    update_virtual_page();
    update_new_counter();
    printf("Page %d is in the physical memory is reaccessed: %d\n", num, result);

  }
  // printf("counter: %d\n", counter);
  for (int m=0; m < FULL_VIRTUAL_ARRAY ; m++){
    printf("virtuafree %d: %d\n", m, virtual_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("time_free %d: %d\n", m, time_page[m]);
  }
  for (int m=0; m < PAGE_NUM ; m++){
    printf("phys_free %d: %d\n", m, phys_page[m]);
  }
  pthread_mutex_unlock(&pm_mutex);
  

}